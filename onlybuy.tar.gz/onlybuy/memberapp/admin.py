from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Promise)
admin.site.register(GoodsType)
admin.site.register(GoodsImg)
admin.site.register(GoodsColor)
admin.site.register(Goods)
admin.site.register(GoodsDetail)
admin.site.register(Banner)
